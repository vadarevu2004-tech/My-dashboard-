"use client";

import { useEffect, useState } from "react";
import { Sparkles, Power, Clock, History } from "lucide-react";

interface SprayLog {
  id: string;
  timestamp: Date;
  duration: string;
  trigger: string;
}

export function SprayMonitor() {
  const [isActive, setIsActive] = useState(false);
  const [lastSprayTime, setLastSprayTime] = useState<Date | null>(null);
  const [sprayLogs, setSprayLogs] = useState<SprayLog[]>([]);
  const [sprayCount, setSprayCount] = useState(12);

  useEffect(() => {
    // Initialize with some logs
    const initialLogs: SprayLog[] = [
      {
        id: "1",
        timestamp: new Date(Date.now() - 3600000),
        duration: "5s",
        trigger: "Auto",
      },
      {
        id: "2",
        timestamp: new Date(Date.now() - 7200000),
        duration: "5s",
        trigger: "Wet Bin Full",
      },
      {
        id: "3",
        timestamp: new Date(Date.now() - 10800000),
        duration: "3s",
        trigger: "Scheduled",
      },
    ];
    setSprayLogs(initialLogs);
    setLastSprayTime(initialLogs[0].timestamp);

    // Simulate occasional spray activations
    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        setIsActive(true);
        setTimeout(() => {
          setIsActive(false);
          const newLog: SprayLog = {
            id: Date.now().toString(),
            timestamp: new Date(),
            duration: `${Math.floor(3 + Math.random() * 5)}s`,
            trigger: ["Auto", "Wet Bin Full", "Scheduled", "Manual"][
              Math.floor(Math.random() * 4)
            ],
          };
          setSprayLogs((prev) => [newLog, ...prev.slice(0, 4)]);
          setLastSprayTime(new Date());
          setSprayCount((prev) => prev + 1);
        }, 3000);
      }
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div
            className={`p-2 rounded-lg transition-all duration-300 ${
              isActive
                ? "bg-primary/20 glow-green animate-pulse-glow"
                : "bg-accent/10"
            }`}
          >
            <Sparkles
              className={`h-6 w-6 transition-colors ${isActive ? "text-primary" : "text-accent"}`}
            />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">
              Disinfectant Spray
            </h3>
            <p className="text-xs text-muted-foreground">
              Automatic hygiene system
            </p>
          </div>
        </div>
      </div>

      {/* Status Card */}
      <div
        className={`p-4 rounded-lg border mb-4 transition-all duration-300 ${
          isActive
            ? "bg-primary/10 border-primary/50 glow-green"
            : "bg-secondary/30 border-border"
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`p-2 rounded-full ${isActive ? "bg-primary/20" : "bg-secondary"}`}
            >
              <Power
                className={`h-5 w-5 ${isActive ? "text-primary" : "text-muted-foreground"}`}
              />
            </div>
            <div>
              <p className="font-semibold text-foreground">Spray Status</p>
              <p className="text-xs text-muted-foreground">
                {isActive ? "Dispensing disinfectant..." : "System ready"}
              </p>
            </div>
          </div>
          <div
            className={`px-3 py-1.5 rounded-full font-semibold text-sm ${
              isActive
                ? "bg-primary text-primary-foreground animate-pulse"
                : "bg-secondary text-muted-foreground"
            }`}
          >
            {isActive ? "ON" : "OFF"}
          </div>
        </div>

        {isActive && (
          <div className="mt-3 pt-3 border-t border-primary/20">
            <div className="flex items-center gap-2">
              <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-primary animate-pulse rounded-full w-full" />
              </div>
              <span className="text-xs text-primary font-mono">Spraying</span>
            </div>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="p-3 bg-secondary/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Clock className="h-4 w-4 text-accent" />
            <span className="text-xs text-muted-foreground">Last Spray</span>
          </div>
          <p className="text-sm font-semibold text-foreground">
            {lastSprayTime
              ? lastSprayTime.toLocaleTimeString()
              : "No spray yet"}
          </p>
        </div>
        <div className="p-3 bg-secondary/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Today</span>
          </div>
          <p className="text-sm font-semibold text-foreground">
            {sprayCount} sprays
          </p>
        </div>
      </div>

      {/* Spray Logs */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 mb-2">
          <History className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium text-foreground">
            Activation Logs
          </span>
        </div>
        <div className="space-y-2 max-h-32 overflow-y-auto">
          {sprayLogs.map((log) => (
            <div
              key={log.id}
              className="flex items-center justify-between p-2 bg-secondary/20 rounded-lg text-xs"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="h-3 w-3 text-primary" />
                <span className="text-muted-foreground">{log.trigger}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-foreground">{log.duration}</span>
                <span className="text-muted-foreground font-mono">
                  {log.timestamp.toLocaleTimeString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
