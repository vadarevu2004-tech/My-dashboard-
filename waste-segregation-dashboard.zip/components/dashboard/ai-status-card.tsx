"use client";

import { useEffect, useState } from "react";
import { Brain, Zap, CheckCircle2, Circle, Cpu, BarChart } from "lucide-react";

interface SensorHealth {
  name: string;
  status: "online" | "offline" | "warning";
}

export function AIStatusCard() {
  const [aiDecision, setAiDecision] = useState("Wet Waste");
  const [confidence, setConfidence] = useState(97.5);
  const [processingTime, setProcessingTime] = useState(45);
  const [sensors, setSensors] = useState<SensorHealth[]>([
    { name: "Camera", status: "online" },
    { name: "Ultrasonic", status: "online" },
    { name: "IR Sensor", status: "online" },
    { name: "Load Cell", status: "online" },
  ]);

  useEffect(() => {
    // Simulate AI decisions
    const interval = setInterval(() => {
      const decisions = [
        "Wet Waste",
        "Dry Waste",
        "Metal Waste",
        "Plastic",
        "Organic",
        "Paper",
      ];
      setAiDecision(decisions[Math.floor(Math.random() * decisions.length)]);
      setConfidence(85 + Math.random() * 14);
      setProcessingTime(30 + Math.random() * 40);

      // Occasionally change sensor status
      if (Math.random() > 0.8) {
        setSensors((prev) =>
          prev.map((s) => ({
            ...s,
            status:
              Math.random() > 0.9
                ? "warning"
                : Math.random() > 0.95
                  ? "offline"
                  : "online",
          }))
        );
      }
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "text-primary bg-primary/20";
      case "warning":
        return "text-warning bg-warning/20";
      case "offline":
        return "text-destructive bg-destructive/20";
      default:
        return "text-muted-foreground bg-muted";
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-lg glow-green">
            <Brain className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">AI Decision Status</h3>
            <p className="text-xs text-muted-foreground">
              Real-time classification
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-2 py-1 bg-primary/10 rounded-full">
          <Zap className="h-3 w-3 text-primary" />
          <span className="text-xs text-primary font-medium">Active</span>
        </div>
      </div>

      {/* Current Decision */}
      <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg mb-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-muted-foreground">
            Latest Classification
          </span>
          <CheckCircle2 className="h-5 w-5 text-primary" />
        </div>
        <p className="text-2xl font-bold text-primary">{aiDecision}</p>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="p-2 bg-secondary/30 rounded-lg">
            <p className="text-xs text-muted-foreground">Confidence</p>
            <p className="text-lg font-semibold text-foreground">
              {confidence.toFixed(1)}%
            </p>
          </div>
          <div className="p-2 bg-secondary/30 rounded-lg">
            <p className="text-xs text-muted-foreground">Processing</p>
            <p className="text-lg font-semibold text-foreground">
              {processingTime.toFixed(0)}ms
            </p>
          </div>
        </div>
      </div>

      {/* Sensor Health */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Cpu className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium text-foreground">
            Sensor Health
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {sensors.map((sensor) => (
            <div
              key={sensor.name}
              className="flex items-center justify-between p-2 bg-secondary/20 rounded-lg"
            >
              <span className="text-xs text-muted-foreground">
                {sensor.name}
              </span>
              <div
                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(sensor.status)}`}
              >
                <Circle className="h-2 w-2 fill-current" />
                {sensor.status}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Connection Quality */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart className="h-4 w-4 text-accent" />
            <span className="text-sm text-muted-foreground">
              Connection Quality
            </span>
          </div>
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className={`w-1.5 rounded-full transition-all ${
                  i <= 4
                    ? "bg-primary h-3"
                    : i <= 4
                      ? "bg-warning h-2"
                      : "bg-muted h-1"
                }`}
                style={{ height: `${6 + i * 3}px` }}
              />
            ))}
            <span className="text-xs text-primary font-medium ml-2">
              Excellent
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
