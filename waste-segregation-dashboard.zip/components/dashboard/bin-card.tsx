"use client";

import { useEffect, useState } from "react";
import { Droplets, Package, Wrench } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface BinCardProps {
  type: "wet" | "dry" | "metal";
  initialLevel: number;
  onAlert?: (type: string, level: number) => void;
}

const binConfig = {
  wet: {
    icon: Droplets,
    label: "Wet Waste",
    description: "Organic & food waste",
    color: "text-primary",
    bgColor: "bg-primary/10",
    borderColor: "border-primary/30",
    glowClass: "glow-green",
  },
  dry: {
    icon: Package,
    label: "Dry Waste",
    description: "Paper, plastic & packaging",
    color: "text-accent",
    bgColor: "bg-accent/10",
    borderColor: "border-accent/30",
    glowClass: "glow-blue",
  },
  metal: {
    icon: Wrench,
    label: "Metal Waste",
    description: "Cans, foils & metal objects",
    color: "text-chart-3",
    bgColor: "bg-chart-3/10",
    borderColor: "border-chart-3/30",
    glowClass: "glow-yellow",
  },
};

export function BinCard({ type, initialLevel, onAlert }: BinCardProps) {
  const [level, setLevel] = useState(initialLevel);
  const [isAnimating, setIsAnimating] = useState(false);
  const config = binConfig[type];
  const Icon = config.icon;

  useEffect(() => {
    // Simulate live data updates
    const interval = setInterval(() => {
      setLevel((prev) => {
        const change = Math.random() > 0.7 ? Math.random() * 5 : -Math.random() * 2;
        const newLevel = Math.max(0, Math.min(100, prev + change));
        
        if (newLevel > 90 && prev <= 90) {
          onAlert?.(config.label, newLevel);
        }
        
        return newLevel;
      });
      setIsAnimating(true);
      setTimeout(() => setIsAnimating(false), 500);
    }, 3000);

    return () => clearInterval(interval);
  }, [config.label, onAlert]);

  const getStatusColor = () => {
    if (level < 50) return "bg-primary";
    if (level < 80) return "bg-warning";
    return "bg-destructive";
  };

  const getStatusText = () => {
    if (level < 25) return "Empty";
    if (level < 50) return "Low";
    if (level < 80) return "Medium";
    if (level < 95) return "Almost Full";
    return "Full";
  };

  const getStatusBadgeColor = () => {
    if (level < 50) return "bg-primary/20 text-primary border-primary/30";
    if (level < 80) return "bg-warning/20 text-warning border-warning/30";
    return "bg-destructive/20 text-destructive border-destructive/30";
  };

  const isAlertState = level >= 90;

  return (
    <div
      className={`relative bg-card border rounded-xl p-5 transition-all duration-300 ${
        isAlertState
          ? "border-destructive/50 glow-red animate-pulse"
          : config.borderColor
      }`}
    >
      {/* Alert indicator */}
      {isAlertState && (
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-destructive rounded-full animate-ping" />
      )}

      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-lg ${config.bgColor} ${isAlertState ? "" : config.glowClass}`}>
            <Icon className={`h-6 w-6 ${isAlertState ? "text-destructive" : config.color}`} />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">{config.label}</h3>
            <p className="text-xs text-muted-foreground">{config.description}</p>
          </div>
        </div>
        <span
          className={`px-2 py-1 text-xs font-medium rounded-full border ${getStatusBadgeColor()}`}
        >
          {getStatusText()}
        </span>
      </div>

      {/* Fill Level */}
      <div className="space-y-3">
        <div className="flex items-baseline justify-between">
          <span className="text-sm text-muted-foreground">Fill Level</span>
          <span
            className={`text-2xl font-bold font-mono transition-all duration-300 ${
              isAnimating ? "scale-110" : ""
            } ${
              level < 50
                ? "text-primary"
                : level < 80
                  ? "text-warning"
                  : "text-destructive"
            }`}
          >
            {level.toFixed(1)}%
          </span>
        </div>

        {/* Progress Bar */}
        <div className="relative h-4 bg-secondary rounded-full overflow-hidden">
          <div
            className={`absolute inset-y-0 left-0 transition-all duration-500 rounded-full ${getStatusColor()}`}
            style={{ width: `${level}%` }}
          />
          {/* Animated shine effect */}
          <div
            className="absolute inset-y-0 left-0 w-full bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse"
            style={{ width: `${level}%` }}
          />
        </div>

        {/* Capacity markers */}
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>0%</span>
          <span>50%</span>
          <span>100%</span>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="mt-4 pt-4 border-t border-border grid grid-cols-2 gap-3">
        <div className="text-center p-2 bg-secondary/30 rounded-lg">
          <p className="text-xs text-muted-foreground">Capacity</p>
          <p className="text-sm font-semibold text-foreground">50L</p>
        </div>
        <div className="text-center p-2 bg-secondary/30 rounded-lg">
          <p className="text-xs text-muted-foreground">Today</p>
          <p className="text-sm font-semibold text-foreground">
            {(level * 0.5).toFixed(1)}L
          </p>
        </div>
      </div>
    </div>
  );
}
