"use client";

import { useEffect, useState } from "react";
import {
  Cpu,
  Wifi,
  Activity,
  Clock,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";

interface ConnectionStatus {
  raspberry: boolean;
  mqtt: boolean;
  health: "good" | "warning" | "critical";
}

export function DashboardHeader() {
  const [dateTime, setDateTime] = useState(new Date());
  const [status, setStatus] = useState<ConnectionStatus>({
    raspberry: true,
    mqtt: true,
    health: "good",
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setDateTime(new Date());
    }, 1000);

    // Simulate occasional status changes
    const statusTimer = setInterval(() => {
      setStatus({
        raspberry: Math.random() > 0.1,
        mqtt: Math.random() > 0.1,
        health: Math.random() > 0.9 ? "warning" : "good",
      });
    }, 5000);

    return () => {
      clearInterval(timer);
      clearInterval(statusTimer);
    };
  }, []);

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  return (
    <header className="bg-card border-b border-border p-4 lg:p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-lg glow-green">
            <Cpu className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-xl lg:text-2xl font-bold text-foreground">
              AI Smart Waste Segregation System
            </h1>
            <p className="text-sm text-muted-foreground">
              Real-time IoT Monitoring Dashboard
            </p>
          </div>
        </div>

        {/* Date & Time */}
        <div className="flex items-center gap-2 bg-secondary/50 px-4 py-2 rounded-lg">
          <Clock className="h-5 w-5 text-accent" />
          <div className="text-sm">
            <p className="text-muted-foreground">{formatDate(dateTime)}</p>
            <p className="text-foreground font-mono font-semibold">
              {formatTime(dateTime)}
            </p>
          </div>
        </div>

        {/* Status Indicators */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Raspberry Pi Status */}
          <div
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${
              status.raspberry
                ? "border-primary/50 bg-primary/10"
                : "border-destructive/50 bg-destructive/10"
            }`}
          >
            <Cpu
              className={`h-4 w-4 ${
                status.raspberry ? "text-primary" : "text-destructive"
              }`}
            />
            <span className="text-xs font-medium">Raspberry Pi</span>
            {status.raspberry ? (
              <CheckCircle2 className="h-4 w-4 text-primary animate-pulse" />
            ) : (
              <AlertCircle className="h-4 w-4 text-destructive animate-blink" />
            )}
          </div>

          {/* MQTT Status */}
          <div
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${
              status.mqtt
                ? "border-accent/50 bg-accent/10"
                : "border-destructive/50 bg-destructive/10"
            }`}
          >
            <Wifi
              className={`h-4 w-4 ${
                status.mqtt ? "text-accent" : "text-destructive"
              }`}
            />
            <span className="text-xs font-medium">MQTT</span>
            {status.mqtt ? (
              <CheckCircle2 className="h-4 w-4 text-accent animate-pulse" />
            ) : (
              <AlertCircle className="h-4 w-4 text-destructive animate-blink" />
            )}
          </div>

          {/* System Health */}
          <div
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${
              status.health === "good"
                ? "border-primary/50 bg-primary/10"
                : status.health === "warning"
                  ? "border-warning/50 bg-warning/10"
                  : "border-destructive/50 bg-destructive/10"
            }`}
          >
            <Activity
              className={`h-4 w-4 ${
                status.health === "good"
                  ? "text-primary"
                  : status.health === "warning"
                    ? "text-warning"
                    : "text-destructive"
              }`}
            />
            <span className="text-xs font-medium">System Health</span>
            <span
              className={`text-xs font-bold uppercase ${
                status.health === "good"
                  ? "text-primary"
                  : status.health === "warning"
                    ? "text-warning"
                    : "text-destructive"
              }`}
            >
              {status.health}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
