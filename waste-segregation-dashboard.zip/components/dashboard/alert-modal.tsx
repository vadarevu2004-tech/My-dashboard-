"use client";

import { AlertTriangle, X, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Alert {
  id: string;
  binType: string;
  level: number;
  timestamp: Date;
}

interface AlertModalProps {
  alert: Alert;
  onClose: () => void;
  onAcknowledge: () => void;
}

export function AlertModal({ alert, onClose, onAcknowledge }: AlertModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-card border border-destructive/50 rounded-xl shadow-2xl glow-red animate-slide-in">
        {/* Flashing header */}
        <div className="bg-destructive/20 border-b border-destructive/30 p-4 rounded-t-xl animate-pulse">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-destructive/30 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-destructive animate-blink" />
              </div>
              <div>
                <h3 className="font-bold text-destructive">BIN FULL ALERT</h3>
                <p className="text-xs text-destructive/80">
                  Immediate attention required
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-destructive/20 rounded-lg transition-colors"
            >
              <X className="h-5 w-5 text-destructive" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <div className="flex items-center gap-3 p-4 bg-destructive/10 border border-destructive/30 rounded-lg">
            <Bell className="h-8 w-8 text-destructive animate-bounce" />
            <div>
              <p className="text-lg font-semibold text-foreground">
                Alert: {alert.binType} is Full
              </p>
              <p className="text-sm text-muted-foreground">
                Current level: {alert.level.toFixed(1)}%
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-secondary/50 rounded-lg text-center">
              <p className="text-xs text-muted-foreground">Timestamp</p>
              <p className="text-sm font-mono font-semibold text-foreground">
                {alert.timestamp.toLocaleTimeString()}
              </p>
            </div>
            <div className="p-3 bg-secondary/50 rounded-lg text-center">
              <p className="text-xs text-muted-foreground">Alert ID</p>
              <p className="text-sm font-mono font-semibold text-foreground">
                {alert.id.slice(0, 8)}
              </p>
            </div>
          </div>

          <div className="p-3 bg-warning/10 border border-warning/30 rounded-lg">
            <p className="text-sm text-warning">
              <span className="font-semibold">Action Required:</span> Please
              empty the bin immediately to ensure proper waste segregation
              continues.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-border flex gap-3">
          <Button
            variant="outline"
            className="flex-1 border-destructive/50 text-destructive hover:bg-destructive/10"
            onClick={onClose}
          >
            Dismiss
          </Button>
          <Button
            className="flex-1 bg-primary hover:bg-primary/90"
            onClick={onAcknowledge}
          >
            Acknowledge
          </Button>
        </div>
      </div>
    </div>
  );
}
