"use client";

import { useEffect, useState } from "react";
import {
  MapPin,
  Navigation,
  Satellite,
  Signal,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface GPSData {
  latitude: number;
  longitude: number;
  area: string;
  accuracy: number;
  satellites: number;
  lastUpdate: Date;
}

export function GPSTracker() {
  const [gpsData, setGpsData] = useState<GPSData>({
    latitude: 17.385,
    longitude: 78.4867,
    area: "Smart Campus Block A",
    accuracy: 3.5,
    satellites: 8,
    lastUpdate: new Date(),
  });
  const [isConnected, setIsConnected] = useState(true);
  const [isTracking, setIsTracking] = useState(false);

  useEffect(() => {
    // Simulate GPS data updates
    const interval = setInterval(() => {
      setGpsData((prev) => ({
        ...prev,
        latitude: prev.latitude + (Math.random() - 0.5) * 0.0001,
        longitude: prev.longitude + (Math.random() - 0.5) * 0.0001,
        accuracy: Math.max(1, prev.accuracy + (Math.random() - 0.5) * 0.5),
        satellites: Math.floor(6 + Math.random() * 6),
        lastUpdate: new Date(),
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleTrackLocation = () => {
    setIsTracking(true);
    setTimeout(() => setIsTracking(false), 2000);
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-accent/10 rounded-lg glow-blue">
            <MapPin className="h-6 w-6 text-accent" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">GPS Location</h3>
            <p className="text-xs text-muted-foreground">
              Real-time bin tracking
            </p>
          </div>
        </div>
        <div
          className={`flex items-center gap-2 px-2 py-1 rounded-full ${
            isConnected
              ? "bg-primary/10 text-primary"
              : "bg-destructive/10 text-destructive"
          }`}
        >
          <span
            className={`w-2 h-2 rounded-full ${
              isConnected ? "bg-primary animate-pulse" : "bg-destructive"
            }`}
          />
          <span className="text-xs font-medium">
            {isConnected ? "Connected" : "Disconnected"}
          </span>
        </div>
      </div>

      {/* Coordinates */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="p-3 bg-secondary/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Navigation className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Latitude</span>
          </div>
          <p className="text-lg font-mono font-bold text-foreground">
            {gpsData.latitude.toFixed(4)}°N
          </p>
        </div>
        <div className="p-3 bg-secondary/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Navigation className="h-4 w-4 text-accent rotate-90" />
            <span className="text-xs text-muted-foreground">Longitude</span>
          </div>
          <p className="text-lg font-mono font-bold text-foreground">
            {gpsData.longitude.toFixed(4)}°E
          </p>
        </div>
      </div>

      {/* Location Card */}
      <div className="p-4 bg-secondary/20 border border-border rounded-lg mb-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-primary/10 rounded-lg">
            <MapPin className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="font-semibold text-foreground">{gpsData.area}</p>
            <p className="text-xs text-muted-foreground">
              Accuracy: ±{gpsData.accuracy.toFixed(1)}m
            </p>
          </div>
          <CheckCircle2 className="h-5 w-5 text-primary" />
        </div>
      </div>

      {/* Map Placeholder */}
      <div className="relative h-40 bg-secondary/30 rounded-lg mb-4 overflow-hidden border border-border">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="relative">
              <MapPin className="h-10 w-10 text-primary mx-auto animate-bounce" />
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-1 bg-primary/30 rounded-full blur-sm" />
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              Live Location Indicator
            </p>
          </div>
        </div>
        {/* Grid overlay */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)",
            backgroundSize: "20px 20px",
          }}
        />
      </div>

      {/* Status Bar */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="flex items-center gap-2 p-2 bg-secondary/30 rounded-lg">
          <Satellite className="h-4 w-4 text-accent" />
          <span className="text-xs text-muted-foreground">Satellites:</span>
          <span className="text-sm font-semibold text-foreground">
            {gpsData.satellites}
          </span>
        </div>
        <div className="flex items-center gap-2 p-2 bg-secondary/30 rounded-lg">
          <Signal className="h-4 w-4 text-primary" />
          <span className="text-xs text-muted-foreground">Signal:</span>
          <span className="text-sm font-semibold text-primary">Strong</span>
        </div>
      </div>

      {/* Track Button */}
      <Button
        className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
        onClick={handleTrackLocation}
        disabled={isTracking}
      >
        {isTracking ? (
          <span className="flex items-center gap-2">
            <span className="w-4 h-4 border-2 border-accent-foreground/30 border-t-accent-foreground rounded-full animate-spin" />
            Tracking...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <Navigation className="h-4 w-4" />
            Track Bin Location
          </span>
        )}
      </Button>

      {/* Last Update */}
      <p className="text-xs text-center text-muted-foreground mt-3">
        Last updated: {gpsData.lastUpdate.toLocaleTimeString()}
      </p>
    </div>
  );
}
