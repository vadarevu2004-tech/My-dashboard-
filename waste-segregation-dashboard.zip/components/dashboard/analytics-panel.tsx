"use client";

import { useEffect, useState } from "react";
import {
  BarChart3,
  PieChart as PieChartIcon,
  TrendingUp,
  Target,
  Recycle,
} from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

interface WasteData {
  name: string;
  value: number;
  color: string;
}

export function AnalyticsPanel() {
  const [totalWaste, setTotalWaste] = useState(127.5);
  const [aiAccuracy, setAiAccuracy] = useState(98.7);
  const [wasteData, setWasteData] = useState<WasteData[]>([
    { name: "Wet", value: 45, color: "oklch(0.7 0.2 160)" },
    { name: "Dry", value: 35, color: "oklch(0.65 0.18 200)" },
    { name: "Metal", value: 20, color: "oklch(0.75 0.22 85)" },
  ]);

  const dailyData = [
    { day: "Mon", wet: 18, dry: 12, metal: 8 },
    { day: "Tue", wet: 22, dry: 15, metal: 10 },
    { day: "Wed", wet: 20, dry: 18, metal: 7 },
    { day: "Thu", wet: 25, dry: 14, metal: 12 },
    { day: "Fri", wet: 19, dry: 16, metal: 9 },
    { day: "Sat", wet: 15, dry: 10, metal: 6 },
    { day: "Sun", wet: 12, dry: 8, metal: 5 },
  ];

  useEffect(() => {
    // Simulate live data updates
    const interval = setInterval(() => {
      setTotalWaste((prev) => prev + Math.random() * 0.5);
      setAiAccuracy((prev) => {
        const change = (Math.random() - 0.5) * 0.2;
        return Math.min(99.9, Math.max(95, prev + change));
      });
      setWasteData((prev) =>
        prev.map((item) => ({
          ...item,
          value: Math.max(10, item.value + (Math.random() - 0.5) * 2),
        }))
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const totalPieValue = wasteData.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-chart-3/10 rounded-lg glow-yellow">
            <BarChart3 className="h-6 w-6 text-chart-3" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">
              Analytics & Statistics
            </h3>
            <p className="text-xs text-muted-foreground">
              Waste management insights
            </p>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <div className="p-3 bg-primary/10 border border-primary/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Recycle className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Today</span>
          </div>
          <p className="text-xl font-bold text-primary">
            {totalWaste.toFixed(1)}
            <span className="text-sm font-normal text-muted-foreground ml-1">
              kg
            </span>
          </p>
        </div>

        <div className="p-3 bg-accent/10 border border-accent/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <Target className="h-4 w-4 text-accent" />
            <span className="text-xs text-muted-foreground">AI Accuracy</span>
          </div>
          <p className="text-xl font-bold text-accent">
            {aiAccuracy.toFixed(1)}
            <span className="text-sm font-normal text-muted-foreground ml-1">
              %
            </span>
          </p>
        </div>

        <div className="p-3 bg-chart-3/10 border border-chart-3/30 rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="h-4 w-4 text-chart-3" />
            <span className="text-xs text-muted-foreground">Weekly</span>
          </div>
          <p className="text-xl font-bold text-chart-3">
            +12
            <span className="text-sm font-normal text-muted-foreground ml-1">
              %
            </span>
          </p>
        </div>

        <div className="p-3 bg-secondary border border-border rounded-lg">
          <div className="flex items-center gap-2 mb-1">
            <PieChartIcon className="h-4 w-4 text-foreground" />
            <span className="text-xs text-muted-foreground">Sorted</span>
          </div>
          <p className="text-xl font-bold text-foreground">
            847
            <span className="text-sm font-normal text-muted-foreground ml-1">
              items
            </span>
          </p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Pie Chart */}
        <div className="bg-secondary/20 rounded-lg p-4 border border-border">
          <h4 className="text-sm font-medium text-foreground mb-3">
            Waste Distribution
          </h4>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={wasteData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {wasteData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "oklch(0.12 0.015 240)",
                    border: "1px solid oklch(0.22 0.025 240)",
                    borderRadius: "8px",
                    color: "oklch(0.95 0 0)",
                  }}
                  formatter={(value: number) => [
                    `${((value / totalPieValue) * 100).toFixed(1)}%`,
                    "Share",
                  ]}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 mt-2">
            {wasteData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-xs text-muted-foreground">
                  {item.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Bar Chart */}
        <div className="bg-secondary/20 rounded-lg p-4 border border-border">
          <h4 className="text-sm font-medium text-foreground mb-3">
            Daily Segregation
          </h4>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyData}>
                <XAxis
                  dataKey="day"
                  tick={{ fill: "oklch(0.65 0.02 240)", fontSize: 12 }}
                  axisLine={{ stroke: "oklch(0.22 0.025 240)" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: "oklch(0.65 0.02 240)", fontSize: 12 }}
                  axisLine={{ stroke: "oklch(0.22 0.025 240)" }}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "oklch(0.12 0.015 240)",
                    border: "1px solid oklch(0.22 0.025 240)",
                    borderRadius: "8px",
                    color: "oklch(0.95 0 0)",
                  }}
                />
                <Bar
                  dataKey="wet"
                  fill="oklch(0.7 0.2 160)"
                  radius={[2, 2, 0, 0]}
                />
                <Bar
                  dataKey="dry"
                  fill="oklch(0.65 0.18 200)"
                  radius={[2, 2, 0, 0]}
                />
                <Bar
                  dataKey="metal"
                  fill="oklch(0.75 0.22 85)"
                  radius={[2, 2, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
