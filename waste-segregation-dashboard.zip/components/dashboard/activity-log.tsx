"use client";

import { useEffect, useState } from "react";
import {
  Activity,
  Droplets,
  RotateCw,
  Sparkles,
  Bell,
  MapPin,
  Cpu,
  Package,
  Wrench,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface LogEntry {
  id: string;
  type: string;
  message: string;
  timestamp: Date;
  icon: LucideIcon;
  color: string;
}

const logTypes = [
  {
    type: "waste_detected",
    messages: [
      "Wet waste detected - Food scraps",
      "Dry waste detected - Plastic bottle",
      "Metal waste detected - Aluminum can",
      "Wet waste detected - Vegetable peels",
      "Dry waste detected - Paper wrapper",
    ],
    icon: Droplets,
    color: "text-primary",
  },
  {
    type: "servo_rotation",
    messages: [
      "Servo rotated to Wet bin",
      "Servo rotated to Dry bin",
      "Servo rotated to Metal bin",
      "Servo returned to default position",
    ],
    icon: RotateCw,
    color: "text-accent",
  },
  {
    type: "spray_activated",
    messages: [
      "Disinfectant spray activated",
      "Automatic spray cycle completed",
      "Hygiene spray triggered",
    ],
    icon: Sparkles,
    color: "text-chart-3",
  },
  {
    type: "bin_alert",
    messages: [
      "Wet bin reaching capacity (85%)",
      "Dry bin emptied successfully",
      "Metal bin at 50% capacity",
    ],
    icon: Bell,
    color: "text-warning",
  },
  {
    type: "gps_updated",
    messages: [
      "GPS location updated",
      "GPS signal strength: Excellent",
      "Location verified: Block A",
    ],
    icon: MapPin,
    color: "text-accent",
  },
  {
    type: "system",
    messages: [
      "AI model classification complete",
      "Sensor calibration successful",
      "System health check passed",
    ],
    icon: Cpu,
    color: "text-primary",
  },
];

export function ActivityLog() {
  const [logs, setLogs] = useState<LogEntry[]>([]);

  useEffect(() => {
    // Initialize with some logs
    const initialLogs: LogEntry[] = [];
    for (let i = 0; i < 8; i++) {
      const logType = logTypes[Math.floor(Math.random() * logTypes.length)];
      const message =
        logType.messages[Math.floor(Math.random() * logType.messages.length)];
      initialLogs.push({
        id: `initial-${i}`,
        type: logType.type,
        message,
        timestamp: new Date(Date.now() - (8 - i) * 30000),
        icon: logType.icon,
        color: logType.color,
      });
    }
    setLogs(initialLogs);

    // Add new logs periodically
    const interval = setInterval(() => {
      const logType = logTypes[Math.floor(Math.random() * logTypes.length)];
      const message =
        logType.messages[Math.floor(Math.random() * logType.messages.length)];
      const newLog: LogEntry = {
        id: Date.now().toString(),
        type: logType.type,
        message,
        timestamp: new Date(),
        icon: logType.icon,
        color: logType.color,
      };

      setLogs((prev) => [newLog, ...prev.slice(0, 19)]);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-accent/10 rounded-lg glow-blue">
            <Activity className="h-6 w-6 text-accent" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Activity Logs</h3>
            <p className="text-xs text-muted-foreground">
              Real-time system events
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-2 py-1 bg-primary/10 rounded-full">
          <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
          <span className="text-xs text-primary font-medium">Live</span>
        </div>
      </div>

      {/* Log List */}
      <div className="space-y-2 max-h-80 overflow-y-auto">
        {logs.map((log, index) => {
          const Icon = log.icon;
          return (
            <div
              key={log.id}
              className={`flex items-start gap-3 p-3 rounded-lg bg-secondary/20 border border-border transition-all duration-300 ${
                index === 0 ? "animate-slide-in" : ""
              }`}
            >
              <div className={`p-1.5 rounded-lg bg-secondary/50`}>
                <Icon className={`h-4 w-4 ${log.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground">{log.message}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {log.timestamp.toLocaleTimeString()}
                </p>
              </div>
              <div
                className={`w-2 h-2 rounded-full ${index === 0 ? "bg-primary animate-pulse" : "bg-muted"}`}
              />
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">
            Showing {logs.length} recent events
          </span>
          <span className="text-primary">Auto-updating</span>
        </div>
      </div>
    </div>
  );
}
