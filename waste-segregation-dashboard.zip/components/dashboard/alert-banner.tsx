"use client";

import { AlertTriangle, X } from "lucide-react";

interface Alert {
  id: string;
  binType: string;
  level: number;
  timestamp: Date;
}

interface AlertBannerProps {
  alerts: Alert[];
  onDismiss: (id: string) => void;
}

export function AlertBanner({ alerts, onDismiss }: AlertBannerProps) {
  if (alerts.length === 0) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-40 p-4 bg-destructive/90 backdrop-blur-sm border-b border-destructive animate-slide-in">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-6 w-6 text-destructive-foreground animate-blink" />
            <div>
              <p className="font-bold text-destructive-foreground">
                EMERGENCY ALERT: {alerts.length} Bin(s) Full
              </p>
              <p className="text-sm text-destructive-foreground/80">
                {alerts.map((a) => `${a.binType} (${a.level.toFixed(0)}%)`).join(", ")}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {alerts.map((alert) => (
              <button
                key={alert.id}
                onClick={() => onDismiss(alert.id)}
                className="flex items-center gap-2 px-3 py-1.5 bg-destructive-foreground/20 hover:bg-destructive-foreground/30 rounded-lg transition-colors"
              >
                <span className="text-sm text-destructive-foreground">
                  Dismiss {alert.binType}
                </span>
                <X className="h-4 w-4 text-destructive-foreground" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
