"use client";

import { useEffect, useState } from "react";
import { Radio, Zap, Bell, MapPin, Gauge, Clock } from "lucide-react";

interface MQTTMessage {
  topic: string;
  message: string;
  timestamp: Date;
}

const topics = [
  { name: "smartbin/status", icon: Gauge, color: "text-primary" },
  { name: "smartbin/alert", icon: Bell, color: "text-destructive" },
  { name: "smartbin/gps", icon: MapPin, color: "text-accent" },
  { name: "smartbin/binlevel", icon: Zap, color: "text-chart-3" },
];

const sampleMessages = [
  { topic: "smartbin/status", message: "System operational" },
  { topic: "smartbin/alert", message: "Wet bin at 85%" },
  { topic: "smartbin/gps", message: "Location updated" },
  { topic: "smartbin/binlevel", message: "Dry: 45%, Wet: 72%, Metal: 38%" },
  { topic: "smartbin/status", message: "AI classification active" },
  { topic: "smartbin/alert", message: "Metal bin emptied" },
  { topic: "smartbin/gps", message: "GPS signal strong" },
  { topic: "smartbin/binlevel", message: "Waste detected: Plastic" },
];

export function MQTTMonitor() {
  const [messages, setMessages] = useState<MQTTMessage[]>([]);
  const [latestWaste, setLatestWaste] = useState("Plastic Bottle");
  const [sensorActivity, setSensorActivity] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  useEffect(() => {
    // Initialize with some messages
    const initialMessages = sampleMessages.slice(0, 4).map((m, i) => ({
      ...m,
      timestamp: new Date(Date.now() - (4 - i) * 5000),
    }));
    setMessages(initialMessages);

    // Simulate live MQTT messages
    const interval = setInterval(() => {
      const randomMessage =
        sampleMessages[Math.floor(Math.random() * sampleMessages.length)];
      const newMessage = {
        ...randomMessage,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev.slice(-9), newMessage]);
      setLastUpdate(new Date());
      setSensorActivity((prev) => !prev);

      // Update latest waste occasionally
      if (Math.random() > 0.7) {
        const wastes = [
          "Plastic Bottle",
          "Food Waste",
          "Aluminum Can",
          "Paper",
          "Organic Matter",
          "Metal Scrap",
        ];
        setLatestWaste(wastes[Math.floor(Math.random() * wastes.length)]);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getTopicConfig = (topicName: string) => {
    return (
      topics.find((t) => t.name === topicName) || {
        icon: Radio,
        color: "text-muted-foreground",
      }
    );
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-lg glow-green">
            <Radio className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">MQTT Live Monitor</h3>
            <p className="text-xs text-muted-foreground">
              Real-time topic messages
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-2 py-1 bg-primary/10 rounded-full">
          <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
          <span className="text-xs text-primary font-medium">Live</span>
        </div>
      </div>

      {/* Topics */}
      <div className="flex flex-wrap gap-2 mb-4">
        {topics.map((topic) => {
          const Icon = topic.icon;
          return (
            <div
              key={topic.name}
              className="flex items-center gap-1.5 px-2 py-1 bg-secondary/30 rounded-lg border border-border"
            >
              <Icon className={`h-3 w-3 ${topic.color}`} />
              <span className="text-xs font-mono text-muted-foreground">
                {topic.name}
              </span>
            </div>
          );
        })}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="p-3 bg-secondary/30 rounded-lg">
          <p className="text-xs text-muted-foreground mb-1">Latest Waste</p>
          <p className="text-sm font-semibold text-foreground">{latestWaste}</p>
        </div>
        <div className="p-3 bg-secondary/30 rounded-lg">
          <p className="text-xs text-muted-foreground mb-1">Sensor Activity</p>
          <div className="flex items-center gap-2">
            <span
              className={`w-2 h-2 rounded-full ${sensorActivity ? "bg-primary animate-pulse" : "bg-muted"}`}
            />
            <span
              className={`text-sm font-semibold ${sensorActivity ? "text-primary" : "text-muted-foreground"}`}
            >
              {sensorActivity ? "Active" : "Idle"}
            </span>
          </div>
        </div>
      </div>

      {/* Message Log */}
      <div className="bg-secondary/20 rounded-lg border border-border p-3 max-h-48 overflow-y-auto">
        <div className="space-y-2">
          {messages.map((msg, index) => {
            const config = getTopicConfig(msg.topic);
            const Icon = config.icon;
            return (
              <div
                key={index}
                className="flex items-start gap-2 p-2 bg-card/50 rounded-lg text-xs animate-in fade-in slide-in-from-right-2 duration-300"
              >
                <Icon className={`h-4 w-4 mt-0.5 ${config.color}`} />
                <div className="flex-1 min-w-0">
                  <p className="font-mono text-muted-foreground truncate">
                    {msg.topic}
                  </p>
                  <p className="text-foreground">{msg.message}</p>
                </div>
                <span className="text-muted-foreground font-mono whitespace-nowrap">
                  {msg.timestamp.toLocaleTimeString()}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Last Update */}
      <div className="flex items-center justify-center gap-2 mt-3">
        <Clock className="h-3 w-3 text-muted-foreground" />
        <p className="text-xs text-muted-foreground">
          Last updated: {lastUpdate.toLocaleTimeString()}
        </p>
      </div>
    </div>
  );
}
